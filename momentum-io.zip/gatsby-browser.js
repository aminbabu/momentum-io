import "@splidejs/react-splide/css";
import "animate.css";
import "aos/dist/aos.css";
import "./src/styles/global.css";
